# Practica matriz

Este es el trabajo para la sesion de matriz de la universidad Carlos III de Madrid
    
## Resultados

Los resultados de todas las practicas se encuentran en /doc

## Integrantes

* Adrian Hernandez
* Álvaro Suárez